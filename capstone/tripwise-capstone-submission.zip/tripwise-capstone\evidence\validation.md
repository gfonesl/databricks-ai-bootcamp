# Tripwise validation record

Date: 2026-08-10

## Deployment and data

- App `tripwise-capstone`: `RUNNING`.
- Lakebase database: `databricks_postgres`, schema: `tripwise`.
- Vectorization task: successful; 6 documents received, 6 documents embedded, 6 chunks written.
- Lakebase verification: 6 knowledge documents, 6 embeddings, cosine HNSW index present.

## MCP

- Authenticated Streamable HTTP handshake: successful.
- MCP tools discovered: 6.
- Search operation: successful.
- Write operation: `create_trip` created trip 1, `Chicago weather-aware validation trip`.

## Quality checks

- `python -m pytest tests -q -p no:cacheprovider`: 8 passed.
- `databricks bundle validate --strict --profile BOOTCAMP`: passed.

## Agent Bricks platform limitation

`Tripwise Travel Agent` exists with `tripwise_mcp_connection` attached. The workspace presently blocks the service's `qwen3-embedding-0-6b` capability (`MODEL_DISABLED`), preventing example creation and a complete managed Agent Bricks response. This does not affect the App, Lakebase, pipeline, or authenticated MCP tool validation.
